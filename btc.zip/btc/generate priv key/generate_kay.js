var bitcoinjs = require('bitcoinjs-lib');

var privKey = process.env.BIP32_PRIV || "xprv9s21ZrQH143K2Nps9oQ3xCuPLrCy2BfJ6uYytn4JiFrYpTBaJAN6wkzw1F36SBEyvvU5dVmjZ8ymXWHN8XaXX1RsALYCnB29u2W4chUgfsE";
var hdNode = bitcoinjs.HDNode.fromBase58(privKey);

var count = process.env.GENERATE_ADDRESSES ? parseInt(process.env.GENERATE_ADDRESSES) : 100; // how many addresses to watch


var rescan = 'false';

for (var i = 1; i <= count; ++i) {
  console.log('bitcoin-cli importprivkey ' +  hdNode.derive(i).keyPair.toWIF() + " '' " + rescan)
}